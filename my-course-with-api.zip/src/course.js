export default [
	{
	  id: "01",
	  name: "Java"
	},
	{
	  id: "02",
	  name: "Angular Js"
	},
	{
	  id: "03",
	  name: "React Js"
	},
	{
	  id: "04",
	  name: "Node Js"
	},
	{
	  id: "05",
	  name: "C++"
	},
	{
	  id: "06",
	  name: "Python"
	}
];